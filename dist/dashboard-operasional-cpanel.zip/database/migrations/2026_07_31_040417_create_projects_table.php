<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('projects', function (Blueprint $table) {
            $table->id();
            $table->string('code')->unique();          // no. proyek, mis. RK-0142
            $table->string('client_name');              // PT ABC
            $table->string('type')->nullable();          // Company Profile, E-commerce, dll
            $table->text('website_features')->nullable(); // isi/fitur yang diminta klien
            $table->text('description')->nullable();      // uraian kebutuhan dari form Request
            $table->boolean('has_client_assets')->nullable(); // jawabannya cuma Ya/Tidak
            $table->enum('status', ['request', 'in_progress', 'completed'])->default('request');
            $table->decimal('value', 15, 2)->nullable();
            $table->date('deadline')->nullable();
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('projects');
    }
};
