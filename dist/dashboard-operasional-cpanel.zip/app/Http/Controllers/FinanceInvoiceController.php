<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Services\Finance\FinanceClock;
use App\Services\Finance\ReminderTimeline;

/**
 * One invoice, in full — read-only.
 */
class FinanceInvoiceController extends Controller
{
    public function show(Invoice $invoice, ReminderTimeline $timeline, FinanceClock $clock)
    {
        // Everything the page reads, in one pass. Without this the items table,
        // the payment list and the timeline would each trigger their own
        // queries per row.
        $invoice->load([
            'client',
            'project.client',
            'subscription',
            'reminderLogs',
        ]);

        return view('finance.invoice-detail', [
            'invoice' => $invoice,
            // Empty for a project invoice, which has no schedule to plot.
            'timeline' => $timeline->for($invoice),
            'billingClient' => $invoice->billableClient(),
            // Default and ceiling for the settlement date, in the zone the
            // business runs on rather than the UTC the app stores.
            'billingToday' => $clock->today(),
        ]);
    }
}
