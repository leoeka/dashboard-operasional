<?php

namespace App\Http\Controllers;

use App\Models\Project;
use App\Services\GoogleAnalyticsService;
use App\Services\SearchConsoleService;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * SEO/backlink tooling: keyword recommendations, PageSpeed, Search
 * Console, GA4, competitor comparison, manual screenshots, and the
 * SEO-only PDF reports. Split out of ProjectController.
 */
class SeoBacklinkController extends Controller
{
    public function analyzeSeoBacklink(Project $project)
    {
        Cache::put(
            \App\Jobs\GenerateKeywordRecommendationsJob::cacheKey($project->id),
            ['status' => 'queued', 'progress' => 0, 'message' => 'Waiting to be processed...'],
            now()->addMinutes(10)
        );

        \App\Jobs\GenerateKeywordRecommendationsJob::dispatch($project);

        return response()->json(['queued' => true]);
    }

    public function seoBacklinkStatus(Project $project)
    {
        return response()->json(
            Cache::get(\App\Jobs\GenerateKeywordRecommendationsJob::cacheKey($project->id), [
                'status' => 'idle',
                'progress' => 0,
                'message' => '',
            ])
        );
    }

    /**
     * Mode PREVIEW: jalankan analisis SEO/Backlink TANPA project di
     * database — dipakai tombol "Analisis Sekarang" di form, sebelum
     * client/project benar-benar dibuat.
     */
    public function analyzeSeoBacklinkPreview(Request $request)
    {
        $data = $request->validate([
            'url' => ['required', 'string', 'max:255'],
            'location' => ['nullable', 'string', 'max:255'],
            'business_name' => ['nullable', 'string', 'max:255'],
            'business_type' => ['nullable', 'string', 'max:255'],
        ]);

        $token = (string) Str::uuid();

        Cache::put(
            $this->previewCacheKey($token),
            ['status' => 'queued', 'progress' => 0, 'message' => 'Waiting to be processed...'],
            now()->addMinutes(15)
        );

        \App\Jobs\RunKeywordPreviewAnalysisJob::dispatch(
            $token,
            $data['url'],
            $data['location'] ?? null,
            $data['business_name'] ?? null,
            $data['business_type'] ?? null,
        );

        return response()->json(['token' => $token]);
    }

    public function seoBacklinkPreviewStatus(Request $request)
    {
        $token = $request->query('token');

        if (!$token) {
            return response()->json(['status' => 'idle', 'progress' => 0, 'message' => '']);
        }

        return response()->json(
            Cache::get($this->previewCacheKey($token), [
                'status' => 'idle',
                'progress' => 0,
                'message' => '',
            ])
        );
    }

    private function previewCacheKey(string $token): string
    {
        return "keyword_preview:{$token}";
    }

    public function analyzePageSpeed(Project $project)
    {
        Cache::put(
            \App\Jobs\AnalyzePageSpeedJob::cacheKey($project->id),
            ['status' => 'queued', 'progress' => 0, 'message' => 'Waiting to be processed...'],
            now()->addMinutes(10)
        );

        \App\Jobs\AnalyzePageSpeedJob::dispatch($project);

        return response()->json(['queued' => true]);
    }

    public function pageSpeedStatus(Project $project)
    {
        return response()->json(
            Cache::get(\App\Jobs\AnalyzePageSpeedJob::cacheKey($project->id), [
                'status' => 'idle',
                'progress' => 0,
                'message' => '',
            ])
        );
    }

    public function analyzeAiCrawlerAccess(Project $project)
    {
        Cache::put(
            \App\Jobs\AnalyzeAiCrawlerAccessJob::cacheKey($project->id),
            ['status' => 'queued', 'progress' => 0, 'message' => 'Waiting to be processed...'],
            now()->addMinutes(10)
        );

        \App\Jobs\AnalyzeAiCrawlerAccessJob::dispatch($project);

        return response()->json(['queued' => true]);
    }

    public function aiCrawlerAccessStatus(Project $project)
    {
        return response()->json(
            Cache::get(\App\Jobs\AnalyzeAiCrawlerAccessJob::cacheKey($project->id), [
                'status' => 'idle',
                'progress' => 0,
                'message' => '',
            ])
        );
    }

    public function analyzeStructuredData(Project $project)
    {
        Cache::put(
            \App\Jobs\AnalyzeStructuredDataJob::cacheKey($project->id),
            ['status' => 'queued', 'progress' => 0, 'message' => 'Waiting to be processed...'],
            now()->addMinutes(10)
        );

        \App\Jobs\AnalyzeStructuredDataJob::dispatch($project);

        return response()->json(['queued' => true]);
    }

    public function structuredDataStatus(Project $project)
    {
        return response()->json(
            Cache::get(\App\Jobs\AnalyzeStructuredDataJob::cacheKey($project->id), [
                'status' => 'idle',
                'progress' => 0,
                'message' => '',
            ])
        );
    }

    public function analyzeCtrGap(Project $project)
    {
        Cache::put(
            \App\Jobs\AnalyzeCtrGapJob::cacheKey($project->id),
            ['status' => 'queued', 'progress' => 0, 'message' => 'Waiting to be processed...'],
            now()->addMinutes(10)
        );

        \App\Jobs\AnalyzeCtrGapJob::dispatch($project);

        return response()->json(['queued' => true]);
    }

    public function ctrGapStatus(Project $project)
    {
        return response()->json(
            Cache::get(\App\Jobs\AnalyzeCtrGapJob::cacheKey($project->id), [
                'status' => 'idle',
                'progress' => 0,
                'message' => '',
            ])
        );
    }

    /**
     * SXO engagement scorecard — dihitung langsung dari data GA4 yang sudah
     * tersimpan (tidak perlu job / panggilan API).
     */
    public function sxoScorecard(Project $project, \App\Services\SxoScorecardService $service)
    {
        $byLandingPage = $project->seo_requirements['google_analytics']['by_landing_page'] ?? [];

        if (empty($byLandingPage)) {
            return response()->json([
                'available' => false,
                'message' => 'Jalankan analisis Google Analytics (GA4) dulu untuk mengisi scorecard ini.',
            ]);
        }

        return response()->json(['available' => true] + $service->build($byLandingPage));
    }

    public function analyzeOnPage(Project $project)
    {
        return $this->dispatchSeoJob($project, \App\Jobs\AnalyzeOnPageJob::class);
    }

    public function onPageStatus(Project $project)
    {
        return $this->seoJobStatus($project, \App\Jobs\AnalyzeOnPageJob::class);
    }

    public function analyzeTechnicalSeo(Project $project)
    {
        return $this->dispatchSeoJob($project, \App\Jobs\AnalyzeTechnicalSeoJob::class);
    }

    public function technicalSeoStatus(Project $project)
    {
        return $this->seoJobStatus($project, \App\Jobs\AnalyzeTechnicalSeoJob::class);
    }

    public function analyzeContentExtractability(Project $project)
    {
        return $this->dispatchSeoJob($project, \App\Jobs\AnalyzeContentExtractabilityJob::class);
    }

    public function contentExtractabilityStatus(Project $project)
    {
        return $this->seoJobStatus($project, \App\Jobs\AnalyzeContentExtractabilityJob::class);
    }

    public function analyzeAeo(Project $project)
    {
        return $this->dispatchSeoJob($project, \App\Jobs\AnalyzeAeoJob::class);
    }

    public function aeoStatus(Project $project)
    {
        return $this->seoJobStatus($project, \App\Jobs\AnalyzeAeoJob::class);
    }

    /** @param class-string $jobClass */
    private function dispatchSeoJob(Project $project, string $jobClass)
    {
        Cache::put(
            $jobClass::cacheKey($project->id),
            ['status' => 'queued', 'progress' => 0, 'message' => 'Waiting to be processed...'],
            now()->addMinutes(15)
        );

        $jobClass::dispatch($project);

        return response()->json(['queued' => true]);
    }

    /** @param class-string $jobClass */
    private function seoJobStatus(Project $project, string $jobClass)
    {
        return response()->json(
            Cache::get($jobClass::cacheKey($project->id), ['status' => 'idle', 'progress' => 0, 'message' => ''])
        );
    }

    public function analyzeSearchConsole(Project $project, SearchConsoleService $service)
    {
        $url = $project->seo_requirements['target_url']
            ?? $project->backlink_requirements['target_url']
            ?? null;

        if (!$url) {
            return response()->json(['success' => false, 'message' => 'Website URL is not available yet.'], 422);
        }

        $result = $service->getPerformance($url);

        if (!$result) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch data — check whether this website is verified in the office Search Console account, or whether the GOOGLE_SEARCH_CONSOLE_REFRESH_TOKEN credential has not been set.',
            ], 422);
        }

        $seo = $project->seo_requirements ?? [];
        $seo['search_console'] = array_merge($result, ['analyzed_at' => now()->toDateTimeString()]);
        $project->update(['seo_requirements' => $seo]);

        $project->logActivity('Search Console report updated');

        return response()->json(['success' => true]);
    }

    public function analyzeGoogleAnalytics(Request $request, Project $project, GoogleAnalyticsService $service)
    {
        $url = $project->seo_requirements['target_url']
            ?? $project->backlink_requirements['target_url']
            ?? null;

        if (!$url) {
            return response()->json(['success' => false, 'message' => 'Website URL is not available yet.'], 422);
        }

        $accessToken = $service->getAccessToken();
        if (!$accessToken) {
            return response()->json([
                'success' => false,
                'message' => 'GA4 credentials are incomplete — check GOOGLE_ANALYTICS_REFRESH_TOKEN in .env.',
            ], 422);
        }

        $seo = $project->seo_requirements ?? [];
        $propertyId = $request->input('property_id') ?: ($seo['ga4_property_id'] ?? null);

        if (!$propertyId) {
            $resolved = $service->resolveProperty($accessToken, $url);

            if ($resolved['status'] === 'ambiguous') {
                return response()->json([
                    'success' => false,
                    'needs_selection' => true,
                    'candidates' => $resolved['candidates'],
                    'message' => 'Found more than 1 matching GA4 Property.',
                ], 422);
            }

            if ($resolved['status'] === 'not_found') {
                return response()->json([
                    'success' => false,
                    'needs_manual_input' => true,
                    'message' => 'Could not automatically find a GA4 Property.',
                ], 422);
            }

            $propertyId = $resolved['property_id'];
        }

        $result = $service->getReport($accessToken, $propertyId);

        if (!$result) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch data from GA4 — check the Property ID or account access to this property.',
            ], 422);
        }

        $seo['ga4_property_id'] = $propertyId;
        $seo['google_analytics'] = array_merge($result, ['analyzed_at' => now()->toDateTimeString()]);
        $project->update(['seo_requirements' => $seo]);

        $project->logActivity('Google Analytics (GA4) report updated');

        return response()->json(['success' => true]);
    }

    public function saveSemrushReport(Request $request, Project $project)
    {
        $data = $request->validate([
            'as_of' => ['nullable', 'date'],
            'metrics.authority_score' => ['nullable', 'numeric', 'between:0,100'],
            'metrics.ai_visibility_score' => ['nullable', 'numeric', 'min:0'],
            'metrics.organic_traffic' => ['nullable', 'integer', 'min:0'],
            'metrics.organic_keywords' => ['nullable', 'integer', 'min:0'],
            'metrics.paid_traffic' => ['nullable', 'integer', 'min:0'],
            'metrics.paid_keywords' => ['nullable', 'integer', 'min:0'],
            'metrics.referring_domains' => ['nullable', 'integer', 'min:0'],
            'metrics.backlinks' => ['nullable', 'integer', 'min:0'],
            'metrics.traffic_share' => ['nullable', 'numeric', 'between:0,100'],
            'ai_platforms_text' => ['nullable', 'string', 'max:2000'],
            'countries_text' => ['nullable', 'string', 'max:2000'],
            'trend_summary' => ['nullable', 'string', 'max:2500'],
            'key_points' => ['nullable', 'string', 'max:2500'],
            'recommendations' => ['nullable', 'string', 'max:2500'],
        ]);

        $metrics = array_filter($data['metrics'] ?? [], fn ($value) => $value !== null && $value !== '');
        $seo = $project->seo_requirements ?? [];
        $seo['semrush_report'] = [
            'as_of' => $data['as_of'] ?? null,
            'metrics' => $metrics,
            'ai_platforms' => $this->parseSemrushRows($data['ai_platforms_text'] ?? '', 3),
            'countries' => $this->parseSemrushRows($data['countries_text'] ?? '', 3),
            'trend_summary' => trim($data['trend_summary'] ?? ''),
            'key_points' => trim($data['key_points'] ?? ''),
            'recommendations' => trim($data['recommendations'] ?? ''),
        ];
        $project->update(['seo_requirements' => $seo]);

        return redirect()->to(route('pages.project-workspace', ['project' => $project->id]) . '#traffic')
            ->with('success', 'Data Semrush untuk laporan SEO berhasil disimpan.');
    }

    /** @return list<array{label:string,first:int,second:int}> */
    private function parseSemrushRows(string $text, int $maximum): array
    {
        $rows = [];
        foreach (array_slice(preg_split('/\r\n|\r|\n/', $text) ?: [], 0, $maximum) as $line) {
            $parts = array_map('trim', explode('|', $line));
            if (count($parts) !== 3 || $parts[0] === '' || !ctype_digit($parts[1]) || !ctype_digit($parts[2])) {
                continue;
            }
            $rows[] = ['label' => mb_substr($parts[0], 0, 100), 'first' => (int) $parts[1], 'second' => (int) $parts[2]];
        }

        return $rows;
    }

    public function downloadSeoBacklinkReport(Project $project)
    {
        return $this->downloadSeoAnalysisReport($project, app(\App\Services\SeoAnalysisReportService::class));
    }

    public function downloadSeoAnalysisReport(Project $project, \App\Services\SeoAnalysisReportService $service)
    {
        $pdf = Pdf::loadView('pdf.seo-analysis-report', $service->assemble($project));
        $clientSlug = Str::slug($project->client_name);

        return $pdf->download("Analysis-SEO-{$clientSlug}-{$project->code}.pdf");
    }

    public function analyzeCompetitorPageSpeed(Project $project)
    {
        \App\Jobs\AnalyzeCompetitorPageSpeedJob::dispatch($project->id);

        Cache::put(
            \App\Jobs\AnalyzeCompetitorPageSpeedJob::cacheKey($project->id),
            ['status' => 'running', 'progress' => 0, 'message' => 'Starting...'],
            now()->addMinutes(10)
        );

        return response()->json(['success' => true]);
    }

    public function selectCompetitors(Request $request, Project $project)
    {
        $validated = $request->validate([
            'selected_urls' => ['nullable', 'array'],
            'selected_urls.*' => ['string'],
            'manual_urls' => ['nullable', 'string'],
        ]);

        $manualUrls = collect(explode("\n", $validated['manual_urls'] ?? ''))
            ->map(fn($u) => trim($u))
            ->filter()
            ->filter(fn($u) => filter_var($u, FILTER_VALIDATE_URL) !== false)
            ->values();

        $checkedUrls = collect($validated['selected_urls'] ?? []);

        $combined = $checkedUrls->merge($manualUrls)->unique()->values();

        if ($combined->count() > 3) {
            return response()->json([
                'success' => false,
                'message' => 'Total competitors (checked + manual) must be at most 3.',
            ], 422);
        }

        if ($combined->isEmpty()) {
            return response()->json([
                'success' => false,
                'message' => 'Select at least 1 competitor.',
            ], 422);
        }

        $seo = $project->seo_requirements ?? [];
        $seo['selected_competitors'] = $combined->all();
        $project->update(['seo_requirements' => $seo]);

        \App\Jobs\AnalyzeCompetitorPageSpeedJob::dispatch($project->id);

        Cache::put(
            \App\Jobs\AnalyzeCompetitorPageSpeedJob::cacheKey($project->id),
            ['status' => 'running', 'progress' => 0, 'message' => 'Starting...'],
            now()->addMinutes(10)
        );

        return response()->json(['success' => true]);
    }

    public function selectKeywords(Request $request, Project $project)
    {
        $validated = $request->validate([
            'selected_keywords' => ['nullable', 'array'],
            'selected_keywords.*' => ['string'],
        ]);

        $selected = collect($validated['selected_keywords'] ?? []);

        $seo = $project->seo_requirements ?? [];
        $mainKeywords = $seo['ai_recommendations']['main_keywords'] ?? [];

        if (empty($mainKeywords)) {
            return response()->json([
                'success' => false,
                'message' => 'No keyword analysis results yet for this project.',
            ], 422);
        }

        $mainKeywords = collect($mainKeywords)
            ->map(function ($kw) use ($selected) {
                $kw['selected'] = $selected->contains($kw['keyword'] ?? null);
                return $kw;
            })
            ->values()
            ->all();

        $seo['ai_recommendations']['main_keywords'] = $mainKeywords;
        $project->update(['seo_requirements' => $seo]);

        $project->logActivity('Keyword selection for proposal updated (' . $selected->count() . ' selected)');

        return response()->json(['success' => true]);
    }

    public function uploadManualScreenshot(Request $request, Project $project)
    {
        $validated = $request->validate([
            'target' => ['required', 'string', 'regex:/^(own_pagespeed|own_semrush|competitor_pagespeed:.+|competitor_semrush:.+)$/'],
            'screenshot' => ['required', 'image', 'max:5120'],
            'return_tab' => ['nullable', 'in:performa,traffic'],
        ]);

        $seo = $project->seo_requirements ?? [];
        $manualScreenshots = $seo['manual_screenshots'] ?? [];

        [$slotKey, $competitorHost] = array_pad(explode(':', $validated['target'], 2), 2, null);
        $isCompetitorSlot = in_array($slotKey, ['competitor_pagespeed', 'competitor_semrush']);

        $existingPath = $isCompetitorSlot
            ? (is_array($manualScreenshots[$slotKey] ?? null) ? ($manualScreenshots[$slotKey][$competitorHost] ?? null) : null)
            : ($manualScreenshots[$slotKey] ?? null);

        if ($existingPath && Storage::disk('public')->exists($existingPath)) {
            Storage::disk('public')->delete($existingPath);
        }

        $newPath = $request->file('screenshot')->store('manual-screenshots/' . $project->id, 'public');

        if ($isCompetitorSlot) {
            if (!isset($manualScreenshots[$slotKey]) || !is_array($manualScreenshots[$slotKey])) {
                $manualScreenshots[$slotKey] = [];   // reset kalau data lama rusak (bukan array)
            }
            $manualScreenshots[$slotKey][$competitorHost] = $newPath;
        } else {
            $manualScreenshots[$slotKey] = $newPath;
        }

        $seo['manual_screenshots'] = $manualScreenshots;
        $project->update(['seo_requirements' => $seo]);

        return $this->manualScreenshotRedirect($request, $project)
            ->with('success', 'Screenshot uploaded successfully.');
    }

    public function deleteManualScreenshot(Request $request, Project $project)
    {
        $validated = $request->validate([
            'target' => ['required', 'string', 'regex:/^(own_pagespeed|own_semrush|competitor_pagespeed:.+|competitor_semrush:.+)$/'],
            'return_tab' => ['nullable', 'in:performa,traffic'],
        ]);

        $seo = $project->seo_requirements ?? [];
        $manualScreenshots = $seo['manual_screenshots'] ?? [];

        [$slotKey, $competitorHost] = array_pad(explode(':', $validated['target'], 2), 2, null);
        $isCompetitorSlot = in_array($slotKey, ['competitor_pagespeed', 'competitor_semrush']);

        $path = $isCompetitorSlot
            ? (is_array($manualScreenshots[$slotKey] ?? null) ? ($manualScreenshots[$slotKey][$competitorHost] ?? null) : null)
            : ($manualScreenshots[$slotKey] ?? null);

        if ($path && Storage::disk('public')->exists($path)) {
            Storage::disk('public')->delete($path);
        }

        if ($isCompetitorSlot) {
            unset($manualScreenshots[$slotKey][$competitorHost]);
        } else {
            unset($manualScreenshots[$slotKey]);
        }

        $seo['manual_screenshots'] = $manualScreenshots;
        $project->update(['seo_requirements' => $seo]);

        return $this->manualScreenshotRedirect($request, $project)
            ->with('success', 'Screenshot deleted.');
    }

    /** Return to the tab that initiated the screenshot action. */
    private function manualScreenshotRedirect(Request $request, Project $project)
    {
        $tab = $request->input('return_tab');
        if (in_array($tab, ['performa', 'traffic'], true)) {
            return redirect()->to(route('pages.project-workspace', ['project' => $project->id]) . '#' . $tab);
        }

        return back();
    }

    public function downloadSeoProposal(Project $project)
    {
        $seo = $project->seo_requirements ?? [];
        $backlink = $project->backlink_requirements ?? [];

        $discoveredCompetitors = collect(explode("\n", $seo['competitors'] ?? ''))
            ->map(fn($u) => trim($u))
            ->filter()
            ->values();

        $pdf = Pdf::loadView('pdf.seo-proposal', [
            'project' => $project,
            'seo' => $seo,
            'backlink' => $backlink,
            'aiRecommendations' => $seo['ai_recommendations'] ?? null,
            'aiTopics' => $seo['ai_identified_topics'] ?? null,
            'discoveredCompetitors' => $discoveredCompetitors,
            'competitorPagespeed' => $seo['competitor_pagespeed'] ?? null,
            'pagespeed' => $seo['pagespeed'] ?? null,
            'generatedAt' => now()->format('d F Y H:i'),
        ]);

        $clientSlug = Str::slug($project->client_name);
        $fileName = "Proposal-SEO-{$clientSlug}-{$project->code}.pdf";

        return $pdf->download($fileName);
    }

    public function downloadSeoSxoGeoReport(Project $project, \App\Services\SeoSxoGeoReportService $service)
    {
        $data = $service->assemble($project);

        $pdf = Pdf::loadView('pdf.seo-sxo-geo-report', $data);
        $clientSlug = Str::slug($project->client_name);

        return $pdf->download("Laporan-SEO-SXO-GEO-AEO-{$clientSlug}-{$project->code}.pdf");
    }

    public function competitorPageSpeedStatus(Project $project)
    {
        return response()->json(
            Cache::get(
                \App\Jobs\AnalyzeCompetitorPageSpeedJob::cacheKey($project->id),
                ['status' => 'idle', 'progress' => 0, 'message' => '']
            )
        );
    }
}
