<?php

namespace App\Services;

use App\Exceptions\ProviderException;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class WhatsAppService
{
    /**
     * Kirim pesan WhatsApp via Fonnte API.
     * Dokumentasi: https://docs.fonnte.com/api-send-message/
     */
    public function send(string $phone, string $message): bool
    {
        $token = config('services.fonnte.token');

        if (!$token) {
            Log::warning('WhatsApp (Fonnte): FONNTE_TOKEN belum diisi di .env, pesan tidak dikirim.', [
                'phone' => $phone,
            ]);
            return false;
        }

        $normalizedPhone = $this->normalizePhoneNumber($phone);

        try {
            $response = Http::withHeaders([
                // FIX: Fonnte TIDAK pakai "Bearer" — token dikirim langsung
                // apa adanya di header Authorization.
                'Authorization' => $token,
            ])->asForm()->post('https://api.fonnte.com/send', [
                        'target' => $normalizedPhone,
                        'message' => $message,
                        'countryCode' => '62',
                    ]);

            $result = $response->json();

            // FIX PENTING: Fonnte bisa balikin HTTP 200 tapi pesan TETAP
            // gagal terkirim (token invalid, nomor invalid, kuota habis,
            // dll) — sukses/gagal yang sebenarnya ada di field "status"
            // dalam body JSON, BUKAN dari status code HTTP semata.
            $success = $result['status'] ?? false;

            if (!$success) {
                Log::warning('WhatsApp (Fonnte): gagal mengirim pesan.', [
                    'phone' => $normalizedPhone,
                    'reason' => ProviderException::sanitise((string) ($result['reason'] ?? 'unknown')),
                ]);
                return false;
            }

            $messageId = $result['id'] ?? '';
            if (is_array($messageId)) {
                $messageId = implode(',', $messageId);
            }

            Log::info('WhatsApp (Fonnte): pesan berhasil dikirim / masuk antrian.', [
                'phone' => $normalizedPhone,
                'detail' => ProviderException::sanitise((string) ($result['detail'] ?? '')),
                'message_id' => ProviderException::sanitise((string) $messageId),
            ]);

            return true;

        } catch (\Throwable $e) {
            Log::error('WhatsApp (Fonnte) Exception: ' . ProviderException::sanitise($e->getMessage()), [
                'phone' => $normalizedPhone,
            ]);
            return false;
        }
    }

    /**
     * Kirim dokumen (mis. PDF invoice) via Fonnte dengan upload langsung (parameter "file").
     * Caption opsional: kalau null/kosong, yang terkirim hanya dokumennya.
     */
    public function sendDocument(string $phone, string $fileContent, string $filename, ?string $caption = null): bool
    {
        $token = config('services.fonnte.token');

        if (!$token) {
            Log::warning('WhatsApp (Fonnte): FONNTE_TOKEN belum diisi di .env, dokumen tidak dikirim.', [
                'phone' => $phone,
            ]);
            return false;
        }

        $normalizedPhone = $this->normalizePhoneNumber($phone);

        $payload = [
            'target' => $normalizedPhone,
            'countryCode' => '62',
            'filename' => $filename,
        ];

        if ($caption !== null && $caption !== '') {
            $payload['message'] = $caption;
        }

        try {
            // attach() otomatis memakai multipart/form-data, jadi JANGAN pakai asForm() di sini.
            $response = Http::withHeaders(['Authorization' => $token])
                ->timeout(60)
                ->attach('file', $fileContent, $filename)
                ->post('https://api.fonnte.com/send', $payload);

            $result = $response->json();

            if (!($result['status'] ?? false)) {
                Log::warning('WhatsApp (Fonnte): gagal mengirim dokumen.', [
                    'phone' => $normalizedPhone,
                    'filename' => $filename,
                    'reason' => ProviderException::sanitise((string) ($result['reason'] ?? 'unknown')),
                ]);
                return false;
            }

            $messageId = $result['id'] ?? '';
            if (is_array($messageId)) {
                $messageId = implode(',', $messageId);
            }

            Log::info('WhatsApp (Fonnte): dokumen berhasil dikirim / masuk antrian.', [
                'phone' => $normalizedPhone,
                'filename' => $filename,
                'detail' => ProviderException::sanitise((string) ($result['detail'] ?? '')),
                'message_id' => ProviderException::sanitise((string) $messageId),
            ]);

            return true;
        } catch (\Throwable $e) {
            Log::error('WhatsApp (Fonnte) sendDocument exception: ' . ProviderException::sanitise($e->getMessage()), [
                'phone' => $normalizedPhone,
            ]);
            return false;
        }
    }

    /**
     * Normalisasi format nomor sebelum dikirim ke Fonnte. Fonnte sendiri
     * sudah otomatis ganti awalan "0" jadi countryCode (default 62), tapi
     * kita bersihkan dulu di sisi kita supaya data yang di-log/disimpan
     * konsisten, dan untuk berjaga-jaga kalau format input dari form ada
     * karakter aneh (spasi, tanda hubung, dll).
     */

    public function sendMany(array $items, string $delay = '60-180'): bool
    {
        $token = config('services.fonnte.token');

        if (!$token) {
            Log::warning('WhatsApp (Fonnte): FONNTE_TOKEN belum diisi di .env, pesan tidak dikirim.');
            return false;
        }

        if (empty($items)) {
            return true;
        }

        $data = array_map(fn($item) => [
            'target' => $this->normalizePhoneNumber($item['phone']),
            'message' => $item['message'],
            'delay' => $delay,
        ], $items);

        try {
            $response = Http::withHeaders(['Authorization' => $token])
                ->timeout(30)
                ->asForm()
                ->post('https://api.fonnte.com/send', [
                    'data' => json_encode($data),
                    'countryCode' => '62',
                ]);

            $result = $response->json();

            if (!($result['status'] ?? false)) {
                Log::warning('WhatsApp (Fonnte): gagal kirim batch.', [
                    'count' => count($items),
                    'reason' => ProviderException::sanitise((string) ($result['reason'] ?? 'unknown')),
                ]);
                return false;
            }

            Log::info('WhatsApp (Fonnte): batch masuk antrian Fonnte.', [
                'count' => count($items),
            ]);

            return true;
        } catch (\Throwable $e) {
            Log::error('WhatsApp (Fonnte) batch exception: ' . ProviderException::sanitise($e->getMessage()));
            return false;
        }
    }

    private function normalizePhoneNumber(string $phone): string
    {
        // Buang semua karakter selain angka dan tanda +
        $phone = preg_replace('/[^\d+]/', '', $phone);

        // Buang tanda + di depan kalau ada (Fonnte terima tanpa +)
        $phone = ltrim($phone, '+');

        // Fonnte otomatis ganti "0" di depan jadi "62" lewat parameter
        // countryCode, tapi kita rapikan juga di sini biar konsisten kalau
        // dipakai/ditampilkan di tempat lain (log, dst).
        if (str_starts_with($phone, '0')) {
            $phone = '62' . substr($phone, 1);
        }

        return $phone;
    }
}