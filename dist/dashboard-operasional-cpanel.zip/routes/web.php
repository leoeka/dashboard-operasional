<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\AiWorkspaceController;
use App\Http\Controllers\SeoBacklinkController;
use App\Http\Controllers\SeoUrlAnalysisController;
use App\Http\Controllers\requestOrderController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\FinanceSubscriptionController;
use App\Http\Controllers\FinanceController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\MockupCandidateController;
use App\Http\Controllers\ClientProposalController;
use App\Http\Controllers\WpBuildController;
use App\Http\Controllers\ReportController;

/*
|--------------------------------------------------------------------------
| Web Routes - SiteFlow
|--------------------------------------------------------------------------
| Mengikuti struktur sidebar:
| Dashboard, Request Project, Proposal AI, Mockup AI, Website Generator,
| Projects, AI Workspace, QA, Reports, Settings
*/
Route::middleware(['auth'])->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');


    // 2. CRM
    // 1. Route Statis & Form (Taruh Paling Atas)
    Route::get('/clients/view', [RequestOrderController::class, 'clients'])->name('pages.crm');
    Route::get('/clients/create', [RequestOrderController::class, 'create'])->name('pages.request');
    Route::post('/clients', [RequestOrderController::class, 'store'])->name('clients.store');

    Route::get('/seo-analysis', [SeoUrlAnalysisController::class, 'create'])->name('pages.seo-analysis');
    Route::post('/seo-analysis', [SeoUrlAnalysisController::class, 'analyze'])->name('pages.seo-analysis.analyze');

    // 2. Route Dynamic Parameter (Taruh Paling Bawah)
    Route::get('/clients/{client}', [RequestOrderController::class, 'clientView'])->name('pages.crm-view');


    // 3. Project
    Route::get('/projects', [ProjectController::class, 'index'])->name('pages.projects');
    Route::get('/projects/{project}', [ProjectController::class, 'show'])->name('pages.projects.show');
    Route::get('/projects/{project}/edit', [ProjectController::class, 'edit'])->name('pages.projects.edit');
    Route::put('/projects/{project}', [ProjectController::class, 'update'])->name('pages.projects.update');
    Route::delete('/projects/{project}', [ProjectController::class, 'destroy'])->name('pages.projects.destroy');
    Route::post('/projects/{project}/files', [ProjectController::class, 'storeFile'])->name('pages.projects.files.store');
    Route::delete('/projects/{project}/files/{file}', [ProjectController::class, 'destroyFile'])->name('pages.projects.files.destroy');
    Route::post('/projects/{project}/design-reference', [ProjectController::class, 'storeReference'])->name('pages.projects.reference.store');

    // 5. AI Workspace
    Route::get('/project-workspace', [AiWorkspaceController::class, 'aiWorkspace'])->name('pages.project-workspace');
    Route::get('/workshop', [AiWorkspaceController::class, 'proposalWorkshop'])->name('pages.workshop');
    Route::post('/projects/{project}/analyze-seo-backlink', [SeoBacklinkController::class, 'analyzeSeoBacklink'])
        ->name('pages.projects.seo-backlink.analyze');
    Route::get('/projects/{project}/analyze-seo-backlink/status', [SeoBacklinkController::class, 'seoBacklinkStatus'])
        ->name('pages.projects.seo-backlink.status');
    Route::post('/seo-backlink/preview/analyze', [SeoBacklinkController::class, 'analyzeSeoBacklinkPreview'])
        ->name('pages.seo-backlink.preview.analyze');
    Route::get('/seo-backlink/preview/status', [SeoBacklinkController::class, 'seoBacklinkPreviewStatus'])
        ->name('pages.seo-backlink.preview.status');
    Route::post('/projects/{project}/pagespeed/analyze', [SeoBacklinkController::class, 'analyzePageSpeed'])
        ->name('pages.projects.pagespeed.analyze');
    Route::get('/projects/{project}/pagespeed/status', [SeoBacklinkController::class, 'pageSpeedStatus'])
        ->name('pages.projects.pagespeed.status');
    Route::post('/projects/{project}/ai-crawler-access/analyze', [SeoBacklinkController::class, 'analyzeAiCrawlerAccess'])
        ->name('pages.projects.ai-crawler-access.analyze');
    Route::get('/projects/{project}/ai-crawler-access/status', [SeoBacklinkController::class, 'aiCrawlerAccessStatus'])
        ->name('pages.projects.ai-crawler-access.status');
    Route::post('/projects/{project}/structured-data/analyze', [SeoBacklinkController::class, 'analyzeStructuredData'])
        ->name('pages.projects.structured-data.analyze');
    Route::get('/projects/{project}/structured-data/status', [SeoBacklinkController::class, 'structuredDataStatus'])
        ->name('pages.projects.structured-data.status');
    Route::post('/projects/{project}/ctr-gap/analyze', [SeoBacklinkController::class, 'analyzeCtrGap'])
        ->name('pages.projects.ctr-gap.analyze');
    Route::get('/projects/{project}/ctr-gap/status', [SeoBacklinkController::class, 'ctrGapStatus'])
        ->name('pages.projects.ctr-gap.status');
    Route::get('/projects/{project}/sxo-scorecard', [SeoBacklinkController::class, 'sxoScorecard'])
        ->name('pages.projects.sxo-scorecard');
    Route::post('/projects/{project}/onpage-audit/analyze', [SeoBacklinkController::class, 'analyzeOnPage'])
        ->name('pages.projects.onpage-audit.analyze');
    Route::get('/projects/{project}/onpage-audit/status', [SeoBacklinkController::class, 'onPageStatus'])
        ->name('pages.projects.onpage-audit.status');
    Route::post('/projects/{project}/technical-seo/analyze', [SeoBacklinkController::class, 'analyzeTechnicalSeo'])
        ->name('pages.projects.technical-seo.analyze');
    Route::get('/projects/{project}/technical-seo/status', [SeoBacklinkController::class, 'technicalSeoStatus'])
        ->name('pages.projects.technical-seo.status');
    Route::post('/projects/{project}/content-extractability/analyze', [SeoBacklinkController::class, 'analyzeContentExtractability'])
        ->name('pages.projects.content-extractability.analyze');
    Route::get('/projects/{project}/content-extractability/status', [SeoBacklinkController::class, 'contentExtractabilityStatus'])
        ->name('pages.projects.content-extractability.status');
    Route::post('/projects/{project}/aeo/analyze', [SeoBacklinkController::class, 'analyzeAeo'])
        ->name('pages.projects.aeo.analyze');
    Route::get('/projects/{project}/aeo/status', [SeoBacklinkController::class, 'aeoStatus'])
        ->name('pages.projects.aeo.status');
    Route::get('/projects/{project}/seo-sxo-geo/report/download', [SeoBacklinkController::class, 'downloadSeoSxoGeoReport'])
        ->name('pages.projects.seo-sxo-geo.report.download');
    Route::post('/projects/{project}/search-console/analyze', [SeoBacklinkController::class, 'analyzeSearchConsole'])
        ->name('pages.projects.search-console.analyze');
    Route::post('/projects/{project}/ga4/analyze', [SeoBacklinkController::class, 'analyzeGoogleAnalytics'])
        ->name('pages.projects.ga4.analyze');
    Route::get('/projects/{project}/seo-backlink/report/download', [SeoBacklinkController::class, 'downloadSeoBacklinkReport'])
        ->name('pages.projects.seo-backlink.report.download');
    Route::get('/projects/{project}/seo-analysis/report/download', [SeoBacklinkController::class, 'downloadSeoAnalysisReport'])
        ->name('pages.projects.seo-analysis.report.download');
    Route::post('/projects/{project}/seo-analysis/semrush', [SeoBacklinkController::class, 'saveSemrushReport'])
        ->name('pages.projects.seo-analysis.semrush.store');
    Route::post('/projects/{project}/competitor-pagespeed/analyze', [SeoBacklinkController::class, 'analyzeCompetitorPageSpeed'])
        ->name('pages.projects.competitor-pagespeed.analyze');
    Route::get('/projects/{project}/competitor-pagespeed/status', [SeoBacklinkController::class, 'competitorPageSpeedStatus'])
        ->name('pages.projects.competitor-pagespeed.status');
    Route::post('/projects/{project}/manual-screenshot', [SeoBacklinkController::class, 'uploadManualScreenshot'])
        ->name('pages.projects.manual-screenshot.store');
    Route::delete('/projects/{project}/manual-screenshot', [SeoBacklinkController::class, 'deleteManualScreenshot'])
        ->name('pages.projects.manual-screenshot.destroy');
    Route::get('/projects/{project}/seo-proposal/download', [SeoBacklinkController::class, 'downloadSeoProposal'])
        ->name('pages.projects.seo-proposal.download');
    Route::post('/projects/{project}/competitors/select', [SeoBacklinkController::class, 'selectCompetitors'])
        ->name('pages.projects.competitors.select');
    Route::post('/projects/{project}/keywords/select', [SeoBacklinkController::class, 'selectKeywords'])
        ->name('pages.projects.keywords.select');

    // Mockup pipeline — gerbang tim di Workspace. Generate berat lewat antrean.
    Route::get('/projects/{project}/mockup-status', [MockupCandidateController::class, 'status'])
        ->name('pages.projects.mockup.status');
    Route::post('/projects/{project}/mockup-candidates', [MockupCandidateController::class, 'store'])
        ->name('pages.projects.mockup.store');
    Route::post('/projects/{project}/mockup-candidates/{candidate}/regenerate', [MockupCandidateController::class, 'regenerate'])
        ->name('pages.projects.mockup.regenerate');
    Route::post('/projects/{project}/mockup-candidates/regenerate-all', [MockupCandidateController::class, 'regenerateAll'])
        ->name('pages.projects.mockup.regenerate-all');
    Route::post('/projects/{project}/mockup-candidates/approve', [MockupCandidateController::class, 'approve'])
        ->name('pages.projects.mockup.approve');
    Route::get('/mockup-candidates/{candidate}/preview.png', [MockupCandidateController::class, 'preview'])
        ->name('pages.projects.mockup.preview');
    Route::get('/mockup-candidates/{candidate}/preview-live', [MockupCandidateController::class, 'previewLive'])
        ->name('pages.projects.mockup.preview-live');
    Route::get('/mockup-candidates/{candidate}/pratinjau', [MockupCandidateController::class, 'previewSite'])
        ->name('pages.projects.mockup.preview-site');

    // Proposal PDF untuk klien — dirakit dari tiga kandidat yang disetujui tim.
    Route::post('/projects/{project}/proposals', [ClientProposalController::class, 'store'])
        ->name('pages.projects.proposals.store');
    Route::get('/projects/{project}/proposals/{proposal}/download', [ClientProposalController::class, 'download'])
        ->name('pages.projects.proposals.download');

    // Pilihan klien (tim mencatat dari PDF yang dikembalikan) + kunci build.
    Route::post('/projects/{project}/proposals/{proposal}/chosen-candidate/{candidate}', [ClientProposalController::class, 'choose'])
        ->name('pages.projects.proposals.choose');
    Route::post('/projects/{project}/builds', [WpBuildController::class, 'store'])
        ->name('pages.projects.builds.store');
    Route::get('/projects/{project}/builds/{build}/download', [WpBuildController::class, 'download'])
        ->name('pages.projects.builds.download');

    // 7. Finance
    // A reminder workspace, not a cash book: payments are settled outside this
    // system. The page reads; the writes are the renewal engine's own reminder
    // retry, the settlement marker below, and the invoice actions.
    Route::get('/finance', [FinanceController::class, 'index'])->name('pages.finance');

    // Invoice detail. The one thing an operator records here is that a bill
    // chased off-system was paid: a status and a date, never an amount.
    Route::get('/finance/invoices/{invoice}', [\App\Http\Controllers\FinanceInvoiceController::class, 'show'])->name('pages.finance.invoices.show');
    Route::patch('/finance/{invoice}/paid', [InvoiceController::class, 'markPaid'])->name('pages.finance.invoices.paid');
    Route::patch('/finance/{invoice}/unpaid', [InvoiceController::class, 'markUnpaid'])->name('pages.finance.invoices.unpaid');

    // Recurring subscriptions. Status changes only, because a subscription is
    // deleted, because billed invoices point at it. The renewal date is no
    // longer an operator's job: the billing engine rolls it forward on the
    // calendar, whether or not the money has arrived.
    Route::get('/finance/subscriptions/create', [FinanceSubscriptionController::class, 'create'])->name('pages.finance.subscriptions.create');
    Route::post('/finance/subscriptions', [FinanceSubscriptionController::class, 'store'])->name('pages.finance.subscriptions.store');
    Route::get('/finance/subscriptions/{subscription}/edit', [FinanceSubscriptionController::class, 'edit'])->name('pages.finance.subscriptions.edit');
    Route::put('/finance/subscriptions/{subscription}', [FinanceSubscriptionController::class, 'update'])->name('pages.finance.subscriptions.update');
    Route::patch('/finance/subscriptions/{subscription}/status', [FinanceSubscriptionController::class, 'updateStatus'])->name('pages.finance.subscriptions.status');
    Route::post('/finance/reminders/{reminderLog}/retry', [FinanceController::class, 'retryReminder'])->name('pages.finance.reminders.retry');
    Route::delete('/finance/{invoice}', [InvoiceController::class, 'destroy'])->name('pages.finance.destroy');

    // 9. Reports
    Route::get('/reports', [ReportController::class, 'index'])->name('pages.reports');
    Route::get('/reports/download', [ReportController::class, 'downloadPdf'])->name('pages.reports.download');
    Route::get('/reports/download-excel', [ReportController::class, 'downloadExcel'])->name('pages.reports.download-excel');
   
    // 10. Profile
    Route::get('/profile', [ProfileController::class, 'index'])->name('profile');
    Route::get('/profile/edit', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    Route::post('/logout', [ProfileController::class, 'logout'])->name('logout');

});

require __DIR__ . '/auth.php';
